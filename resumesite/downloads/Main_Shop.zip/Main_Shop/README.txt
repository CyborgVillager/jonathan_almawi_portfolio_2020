Hello and thank you for downloading main_shop program.

This was part of my OOP final for 2019 fall semester. The main objectives
were to make a book or dvd store that the user will be able to see, edit
delete, and checkout with taxes.

All of this was originally part of a terminal. So I just modified it to
have a GUI interface for better user handling, and just because I felt like
it would give this project a better umph.

Much more better visually than to type what you want to buy, see, and do
higher chance to make a typo and get either an except error, or some other 
issues.

GUI interface helps solve's human typing error quite a lot.

Anyhow to use this program just click on main_shop either with the shop icon
or the floppy icon, they both will launch the program.

To edit/add a book you have to make sure to select the line and get it high-
lighted , otherwise nothing will happen. Besides that the functionality
and design are 100% working. Added a couple of other features just in case
the user accidently exited the program, and other fun stuff.

Feel free to test out the program, anyhow have a great day.
~Jonathan Almawi